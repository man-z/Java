package headfirst.combined.djview;
  
public interface BPMObserver {
	void updateBPM();
}
