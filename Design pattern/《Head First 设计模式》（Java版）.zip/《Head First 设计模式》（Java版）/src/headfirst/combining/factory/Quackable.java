package headfirst.combining.factory;

public interface Quackable {
	public void quack();
}
