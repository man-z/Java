package headfirst.observer.weather;

public interface DisplayElement {
	public void display();
}
